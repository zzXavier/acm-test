declare const __DATE__: string
