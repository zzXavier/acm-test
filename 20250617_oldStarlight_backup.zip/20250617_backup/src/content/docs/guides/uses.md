---
title: 常用网址
---

cs自学指南：https://csdiy.wiki/  
cs50x2024: https://cs50.harvard.edu/x/2024/  
OI WIKI学习资源库：https://oi-wiki.org//  
markdown学习：https://markdown.com.cn/cheat-sheet.html  
starrycoding：https://www.starrycoding.com/  
洛谷：https://www.luogu.com.cn/  
w3schools网站学习：https://cn.w3schools.com/default.asp
