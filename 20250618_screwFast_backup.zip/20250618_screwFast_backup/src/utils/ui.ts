export const languages = {
    en: "English",
    fr: "Français",
};